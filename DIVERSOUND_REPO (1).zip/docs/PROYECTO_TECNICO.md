# 📘 PROYECTO TÉCNICO: DIVERSOUND

## IDEA CENTRAL DEL PROYECTO
Diseñar una aplicación móvil de búsqueda de canciones que promueva la diversidad musical, mejore la accesibilidad y ofrezca recomendaciones más personalizadas, especialmente de artistas independientes y géneros poco conocidos.

## 1. Definición del problema de partida del proyecto
Las aplicaciones de música actuales tienden a recomendar canciones basadas en algoritmos limitados y centrados en artistas populares, lo que dificulta el descubrimiento de música diversa e independiente.  
Además, muchas de estas apps presentan barreras de accesibilidad, problemas de personalización real y escasa representación de géneros no comerciales, afectando a usuarios con gustos diversos o necesidades especiales.

## 2. Definición de objetivo general y específicos del proyecto
**Objetivo general:**  
Diseñar y prototipar una aplicación móvil que permita buscar y descubrir canciones de manera inclusiva, diversa y personalizada.

**Objetivos específicos:**
- Identificar las limitaciones actuales de búsqueda musical en apps populares.  
- Integrar filtros de búsqueda avanzada por idioma, género, ritmo, época y estado de ánimo.  
- Crear un sistema de recomendaciones que promueva artistas independientes y géneros emergentes.  

**Tipo de análisis requerido:**
- Análisis comparativo de apps existentes.  
- Análisis de necesidades del usuario (encuestas, entrevistas).  
- Análisis funcional y de experiencia de usuario (UX/UI).  

## 3. Definición de alcance del proyecto
- **Alcance funcional:** Se desarrollará un prototipo interactivo (en Figma o similar) que muestre el diseño y funcionalidades clave de la app.  
- **Alcance geográfico:** El enfoque inicial será en usuarios hispanohablantes, con posibilidad de expansión.  
- **Audiencia objetivo:** Usuarios de música con gustos diversos, personas con discapacidad y oyentes que buscan música fuera del mainstream.  
- **Limitaciones:** No se desarrollará el backend ni la app completa, solo el diseño conceptual y funcional.  

## 4. Definición de metodología del proyecto
**Metodología de diseño centrado en el usuario (DCU):**
1. Investigación: Revisión de apps existentes, encuestas, entrevistas.  
2. Definición: Identificación de necesidades clave y problemáticas prioritarias.  
3. Ideación: Creación de wireframes y definición de funcionalidades innovadoras.  
4. Prototipado: Desarrollo de un prototipo visual (Figma, Adobe XD).  
5. Evaluación: Pruebas de usabilidad con usuarios reales y ajustes al diseño.  

## 5. Análisis de posibles fuentes de datos e instrumentos para obtenerlos
**Fuentes de datos primarios:**
- Encuestas a usuarios de apps como Spotify, YouTube Music o Apple Music.  
- Entrevistas a personas con discapacidad sobre uso de apps musicales.  
- Grupos focales con músicos independientes.  

**Fuentes de datos secundarios:**
- Estudios académicos sobre algoritmos de recomendación musical.  
- Informes de tendencias en streaming musical.  
- Documentación oficial de accesibilidad (como WCAG).  

**Instrumentos:**
- Google Forms o Typeform (para encuestas).  
- Figma o Adobe XD (para prototipos).  
- Miro o Notion (para mapeo de ideas y diseño de experiencia).  
