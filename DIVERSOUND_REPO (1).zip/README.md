# 🎶 DIVERSOUND

**DIVERSOUND** es un proyecto técnico que busca diseñar una aplicación móvil para descubrir canciones de forma inclusiva y diversa.  
El enfoque está en **promover artistas independientes, mejorar la accesibilidad y ofrecer recomendaciones personalizadas**.

## 🚀 Objetivo General
Diseñar y prototipar una aplicación móvil que permita buscar y descubrir canciones de manera inclusiva, diversa y personalizada.

## 🎯 Objetivos Específicos
- Identificar las limitaciones actuales de búsqueda musical en apps populares.  
- Integrar filtros de búsqueda avanzada por idioma, género, ritmo, época y estado de ánimo.  
- Crear un sistema de recomendaciones que promueva artistas independientes y géneros emergentes.  

## 👥 Integrantes
- Dilan Varon  
- Santiago Medina  
- Juan Muñoz  

## 📂 Documentación
Revisa el documento técnico completo aquí 👉 [docs/PROYECTO_TECNICO.md](docs/PROYECTO_TECNICO.md)

---
⚡ Proyecto en fase de diseño y prototipado (Figma/Adobe XD).
